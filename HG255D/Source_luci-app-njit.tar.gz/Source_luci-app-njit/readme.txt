﻿1.将所有文件夹加入luci源码包/feeds/luci/luci/luci
2.自己想办法把luci-app-njit弄进menuconfig目录里
3.make menuconfig选中luci-app-njit，或M或*
4.make之
5.发现任何bug或建议请前往http://www.right.com.cn/forum/thread-110404-1-1.html，望不吝赐教！
